import java.util.Scanner;

public class u04 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        System.out.println("Ivesk intervalo pradzia: ");
        int a = reader.nextInt();
        System.out.println("Ivesk intervalo pabaiga: ");
        int b = reader.nextInt();

        int suma = 0;

        for (int i = a; i <= b; i++) {
            if (i % 6 == 0) {
                suma++;
            }
        }

        System.out.println("Reikalingas marskineliu skaicius: " + suma);

        //reader.close();
    }
}
