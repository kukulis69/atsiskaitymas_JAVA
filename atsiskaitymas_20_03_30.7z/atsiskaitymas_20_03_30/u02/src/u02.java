import java.util.Scanner;

public class u02 {

    public static void main(String[] args) {

        Scanner reader = new Scanner(System.in);

        System.out.println("Ivesk deziu skaiciu");

        int dezsk = reader.nextInt();

        System.out.println("Ivesk knygu kaiciu");

        int knygsk = reader.nextInt();

        System.out.println("Ivesk kiek knygu telpa i deze");

        int telpask = reader.nextInt();

        int lieka = knygsk - (dezsk * telpask);

        if (knygsk >= (dezsk * telpask)) {
            System.out.println("netelpa, lieka " + lieka + " knygu");
        } else {
            System.out.println("telpa");
        }


    }
}
