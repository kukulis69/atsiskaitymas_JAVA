import java.util.Scanner;

public class u01 {
    public static void main(String[] args) {

        Scanner reader = new Scanner(System.in);
        System.out.println("Kiek pamoku kasdien (5is kartus)?");

        int prm = reader.nextInt();
        int ant = reader.nextInt();
        int trc = reader.nextInt();
        int kt = reader.nextInt();
        int pn = reader.nextInt();

        int sk = prm + ant + trc + kt + pn;
        int minut = sk * 45;

        System.out.println("PAmoku sk: " + sk);
        System.out.println("Tai sudaaro minuciu: " + minut);
    }
}
