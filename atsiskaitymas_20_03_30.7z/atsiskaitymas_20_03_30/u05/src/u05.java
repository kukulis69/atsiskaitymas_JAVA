import java.util.Scanner;

public class u05 {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);

        System.out.println("Duota ");
        int p1 = reader.nextInt();
        int p2 = reader.nextInt();
        int p3 = reader.nextInt();


        //gautiGeriausiaIvertinima();


        System.out.println("Rezultatas " + metodai.gautiGeriausiaIvertinima(p1, p2, p3));
    }
}
