public class uuzd03 {
    public static void main(String[] args) {

        System.out.println("Ciklas for: ");
        for (int i = -100; i >= -199; i -= 3) {
            System.out.print(i + " ");
        }

        System.out.println();
        System.out.println("Ciklas while: ");
        int i = -100;

        while (i >= -199) {
            System.out.print(i + " ");
            i = i - 3;
        }
    }
}
